﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyRecipes.Models
{
    public class EFChefRepository:IChefRepository
    {
        private ApplicationDbContext context;
        public EFChefRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public IQueryable<Chef> Chefs => context.Chefs;

        public void SaveChef (Chef chef)
        {
            if (chef.ChefId == 0)
            {
                context.Chefs.Add(chef);
            }
            else
            {
                Chef chefEntry = context.Chefs
                    .FirstOrDefault(r => r.ChefId == chef.ChefId);

                if (chefEntry != null)
                {
                    chefEntry.ChefName = chef.ChefName;
                    chefEntry.Specialty = chef.Specialty;
                    chefEntry.YearsOfExperience = chef.YearsOfExperience;
                    chefEntry.IsEmployed = chef.IsEmployed;

                }

            }
            context.SaveChanges();
        }

        public Chef DeleteChef(int chefId)
        {
            Chef chefEntry = context.Chefs
                  .FirstOrDefault(r => r.ChefId == chefId);
            if (chefEntry != null)
            {

                context.Chefs.Remove(chefEntry);
                context.SaveChanges();
            }
            return chefEntry;
        }
    }
}




