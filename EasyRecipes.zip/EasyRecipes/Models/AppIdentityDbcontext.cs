﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EasyRecipes.Models
{
    public class AppIdentityDbcontext : IdentityDbContext<IdentityUser>
    {
        public AppIdentityDbcontext(DbContextOptions<AppIdentityDbcontext> options)
            : base(options) { }

    }
}
